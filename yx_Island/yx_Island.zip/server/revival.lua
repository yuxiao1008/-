-- 佩里科岛系统 - 复活系统服务端
-- 作者: 于晓

local QBCore = exports['qb-core']:GetCoreObject()

-- ==================== 全局变量 ====================
-- 玩家复活次数记录 {source = count}
PlayerReviveCount = {}

-- ==================== 调试函数 ====================
local function debug_print(msg)
    if Config.Debug then
        print("[yx_Island REVIVAL] " .. msg)
    end
end

-- ==================== 核心函数 ====================

-- 获取玩家已复活次数
function GetReviveCount(source)
    return PlayerReviveCount[source] or 0
end

-- 增加玩家复活次数
function IncrementReviveCount(source)
    local count = GetReviveCount(source)
    PlayerReviveCount[source] = count + 1
    debug_print(string.format("玩家 %s 复活次数: %d -> %d", GetPlayerName(source), count, count + 1))
    return PlayerReviveCount[source]
end

-- 检查玩家是否还有复活机会
function CanRevive(source)
    local count = GetReviveCount(source)
    local canRevive = count < Config.Revival.max_revives
    debug_print(string.format("玩家 %s 复活检查: %d/%d - %s",
        GetPlayerName(source), count, Config.Revival.max_revives,
        canRevive and "可以复活" or "次数已用尽"))
    return canRevive
end

-- 重置所有玩家复活次数
function ResetAllReviveCounts()
    local count = 0
    for source, _ in pairs(PlayerReviveCount) do
        count = count + 1
    end
    PlayerReviveCount = {}
    debug_print(string.format("已重置 %d 个玩家的复活次数", count))
    return count
end

-- 创建死亡背包（如果玩家有物品）并清空背包
function CreateDeathBagIfNeeded(source, deathCoords)
    local Player = QBCore.Functions.GetPlayer(source)
    if not Player then
        debug_print(string.format("玩家 %s 不存在，无法创建死亡背包", source))
        return
    end

    -- 检查玩家是否有任何物品
    local hasItems = false
    if Player.PlayerData.items then
        for _, item in pairs(Player.PlayerData.items) do
            if item and item.amount and item.amount > 0 then
                hasItems = true
                break
            end
        end
    end

    if hasItems then
        -- 调用现有的死亡背包创建函数（会自动清空背包）
        local success = CreateDeathBag(source, deathCoords)
        if success then
            debug_print(string.format("玩家 %s 死亡背包已创建 at %s", GetPlayerName(source), deathCoords))
        else
            debug_print(string.format("玩家 %s 死亡背包创建失败，物品保留", GetPlayerName(source)))
            -- 实体创建失败，清空背包避免物品被保留
            ClearPlayerInventory(source)
        end
    else
        -- 没有物品，但仍然需要清空背包
        ClearPlayerInventory(source)
        debug_print(string.format("玩家 %s 无物品，跳过死亡背包创建，但已清空背包", GetPlayerName(source)))
    end
end

-- 将玩家踢出活动（复活次数用尽时）
function KickPlayerFromActivity(source)
    local playerName = GetPlayerName(source)
    debug_print(string.format("玩家 %s 复活次数用尽，强制退出活动", playerName))

    -- 添加到已撤离玩家列表
    local Player = QBCore.Functions.GetPlayer(source)
    if Player then
        EvacuatedPlayers[source] = {
            name = Player.PlayerData.charinfo.firstname .. " " .. Player.PlayerData.charinfo.lastname,
            reason = '死亡次数过多'
        }
    end

    -- 清除背包备份（不恢复物品）
    if PlayerInventoryBackup[source] then
        PlayerInventoryBackup[source] = nil
        debug_print(string.format("玩家 %s 的背包备份已清除（不恢复）", playerName))
    end

    -- 清除岛屿状态
    SetPlayerIslandStatus(source, false)

    -- 通知玩家
    TriggerClientEvent('QBCore:Notify', source, Config.Revival.notifications.max_revives_reached, 'error')

    -- 传送回集结点
    SetTimeout(2000, function()
        TriggerClientEvent('yx_island:client:teleport_to_return', source)
    end)
end

-- 扣除携带武器的费用
local function ChargeWeaponCost(source, cost)
    local Player = QBCore.Functions.GetPlayer(source)
    if not Player then
        debug_print(string.format("玩家 %s 不存在，无法扣费", source))
        return false
    end

    local cash = Player.PlayerData.money.cash or 0
    local bank = Player.PlayerData.money.bank or 0
    local total = cash + bank

    -- 检查总余额是否足够
    if total < cost then
        debug_print(string.format("玩家 %s 余额不足: 需要 $%d, 现金 $%d, 银行 $%d",
            GetPlayerName(source), cost, cash, bank))
        return false
    end

    -- 优先扣除现金
    if cash >= cost then
        Player.Functions.RemoveMoney('cash', cost, '携带武器复活费用')
        debug_print(string.format("玩家 %s 支付 $%d (现金)", GetPlayerName(source), cost))
    else
        -- 现金不足，先扣完现金再扣银行
        if cash > 0 then
            Player.Functions.RemoveMoney('cash', cash, '携带武器复活费用')
            debug_print(string.format("玩家 %s 支付 $%d (现金)", GetPlayerName(source), cash))
        end

        local remaining = cost - cash
        Player.Functions.RemoveMoney('bank', remaining, '携带武器复活费用')
        debug_print(string.format("玩家 %s 支付 $%d (银行)", GetPlayerName(source), remaining))
    end

    return true
end

-- 执行复活并重新空投
local function ReviveAndAirdrop(source, giveWeapon)
    local playerName = GetPlayerName(source)

    -- 增加复活次数
    IncrementReviveCount(source)

    -- 发送成功通知
    TriggerClientEvent('QBCore:Notify', source, Config.Revival.notifications.revival_success, 'success')

    -- 延迟后触发空投
    SetTimeout(2000, function()
        TriggerClientEvent('yx_island:client:start_airdrop', source)
        debug_print(string.format("玩家 %s 开始重新空投", playerName))

        -- 如果需要给予武器，等待15秒后（着陆后）给予物品
        if giveWeapon then
            TriggerClientEvent('QBCore:Notify', source, Config.Revival.notifications.weapon_incoming, 'primary')

            SetTimeout(Config.Revival.weapon_give_delay, function()
                local Player = QBCore.Functions.GetPlayer(source)
                if not Player then
                    debug_print(string.format("玩家 %s 不存在，无法给予武器", source))
                    return
                end

                -- 给予武器物品
                local success = Player.Functions.AddItem(Config.Revival.weapon_item, Config.Revival.weapon_amount)

                if success then
                    -- 触发物品提示动画
                    TriggerClientEvent('inventory:client:ItemBox', source,
                        QBCore.Shared.Items[Config.Revival.weapon_item], 'add', Config.Revival.weapon_amount)

                    local weaponLabel = Config.Revival.weapon_label
                    TriggerClientEvent('QBCore:Notify', source,
                        Config.Revival.notifications.weapon_received .. weaponLabel, 'success')

                    debug_print(string.format("玩家 %s 已获得武器物品: %s x%d", playerName,
                        Config.Revival.weapon_item, Config.Revival.weapon_amount))
                else
                    debug_print(string.format("玩家 %s 背包已满，无法获得武器", playerName))
                    TriggerClientEvent('QBCore:Notify', source, '背包空间不足，无法获得武器!', 'error')
                end
            end)
        end
    end)
end

-- ==================== 事件处理 ====================

-- 玩家选择携带武器复活
RegisterNetEvent('yx_island:server:revive_with_weapon', function()
    local source = source
    local playerName = GetPlayerName(source)

    debug_print(string.format("玩家 %s 选择携带武器复活", playerName))

    -- 验证玩家状态
    if not IslandPlayers[source] then
        debug_print(string.format("玩家 %s 不在岛上玩家列表中", playerName))
        return
    end

    -- 验证复活次数
    if not CanRevive(source) then
        TriggerClientEvent('QBCore:Notify', source, Config.Revival.notifications.max_revives_reached, 'error')
        return
    end

    -- 扣除费用
    local charged = ChargeWeaponCost(source, Config.Revival.weapon_cost)
    if not charged then
        TriggerClientEvent('QBCore:Notify', source, Config.Revival.notifications.insufficient_funds, 'error')
        return
    end

    -- 执行复活（带武器）
    ReviveAndAirdrop(source, true)
end)

-- 玩家选择空手复活
RegisterNetEvent('yx_island:server:revive_without_weapon', function()
    local source = source
    local playerName = GetPlayerName(source)

    debug_print(string.format("玩家 %s 选择空手复活", playerName))

    -- 验证玩家状态
    if not IslandPlayers[source] then
        debug_print(string.format("玩家 %s 不在岛上玩家列表中", playerName))
        return
    end

    -- 验证复活次数
    if not CanRevive(source) then
        TriggerClientEvent('QBCore:Notify', source, Config.Revival.notifications.max_revives_reached, 'error')
        return
    end

    -- 执行复活（无武器）
    ReviveAndAirdrop(source, false)
end)

-- 玩家选择放弃复活
RegisterNetEvent('yx_island:server:decline_revival', function()
    local source = source
    local playerName = GetPlayerName(source)

    debug_print(string.format("玩家 %s 选择放弃复活", playerName))

    -- 踢出活动
    KickPlayerFromActivity(source)

    -- 发送通知
    TriggerClientEvent('QBCore:Notify', source, Config.Revival.notifications.revival_declined, 'error')
end)

-- ==================== 玩家掉线清理 ====================

AddEventHandler('playerDropped', function()
    local source = source
    local playerName = GetPlayerName(source)

    -- 清理复活次数记录
    if PlayerReviveCount[source] then
        PlayerReviveCount[source] = nil
        debug_print(string.format("玩家 %s 掉线，已清理复活次数记录", playerName))
    end
end)

-- ==================== 导出函数 ====================

exports('GetReviveCount', GetReviveCount)
exports('IncrementReviveCount', IncrementReviveCount)
exports('CanRevive', CanRevive)
exports('ResetAllReviveCounts', ResetAllReviveCounts)
exports('CreateDeathBagIfNeeded', CreateDeathBagIfNeeded)
exports('KickPlayerFromActivity', KickPlayerFromActivity)

print("^2[yx_Island]^0 复活系统服务端模块已加载")
