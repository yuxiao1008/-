-- 佩里科岛系统 - 复活系统客户端
-- 作者: 于晓

-- ==================== 调试函数 ====================
local function debug_print(msg)
    if Config.Debug then
        print("[yx_Island REVIVAL] " .. msg)
    end
end

-- ==================== 事件处理 ====================

-- 显示复活选择菜单
RegisterNetEvent('yx_island:client:show_revival_menu', function(deathCount, remaining, weaponCost)
    debug_print(string.format("显示复活菜单: 死亡 %d 次, 剩余复活次数 %d", deathCount, remaining))

    -- 构建菜单描述
    local description = string.format(Config.Revival.menu.description_template, deathCount, remaining)

    -- 构建菜单选项
    local options = {
        {
            title = string.format(Config.Revival.menu.options.with_weapon.title, weaponCost),
            description = string.format(Config.Revival.menu.options.with_weapon.description,
                weaponCost, Config.Revival.weapon_label),
            icon = Config.Revival.menu.options.with_weapon.icon,
            onSelect = function()
                debug_print("玩家选择: 携带武器复活")
                TriggerServerEvent('yx_island:server:revive_with_weapon')
            end
        },
        {
            title = Config.Revival.menu.options.without_weapon.title,
            description = Config.Revival.menu.options.without_weapon.description,
            icon = Config.Revival.menu.options.without_weapon.icon,
            onSelect = function()
                debug_print("玩家选择: 空手复活")
                TriggerServerEvent('yx_island:server:revive_without_weapon')
            end
        },
        {
            title = Config.Revival.menu.options.decline.title,
            description = Config.Revival.menu.options.decline.description,
            icon = Config.Revival.menu.options.decline.icon,
            onSelect = function()
                debug_print("玩家选择: 放弃复活")
                TriggerServerEvent('yx_island:server:decline_revival')
            end
        }
    }

    -- 注册并显示菜单
    lib.registerContext({
        id = 'revival_choice_menu',
        title = Config.Revival.menu.title,
        description = description,
        options = options
    })

    lib.showContext('revival_choice_menu')
end)

-- 传送到航空母舰
RegisterNetEvent('yx_island:client:teleport_to_carrier', function()
    local playerPed = PlayerPedId()

    debug_print("开始传送玩家到航空母舰")

    -- 淡出效果
    DoScreenFadeOut(500)
    Wait(500)

    -- 使用更可靠的传送方法
    local targetCoords = Config.Revival.waiting_point
    local targetHeading = Config.Revival.waiting_heading

    debug_print(string.format("目标坐标: %.2f, %.2f, %.2f", targetCoords.x, targetCoords.y, targetCoords.z))

    -- 请求碰撞加载
    RequestCollisionAtCoord(targetCoords.x, targetCoords.y, targetCoords.z)

    -- 传送玩家
    SetEntityCoordsNoOffset(playerPed, targetCoords.x, targetCoords.y, targetCoords.z, false, false, false)
    SetEntityHeading(playerPed, targetHeading)

    -- 冻结玩家，防止掉落
    FreezeEntityPosition(playerPed, true)

    -- 等待加载地面
    local attempts = 0
    while not HasCollisionLoadedAroundEntity(playerPed) and attempts < 100 do
        Wait(10)
        attempts = attempts + 1
    end

    debug_print(string.format("碰撞加载完成 (尝试次数: %d)", attempts))

    -- 确保玩家在地面上
    SetPedCoordsKeepVehicle(playerPed, targetCoords.x, targetCoords.y, targetCoords.z)

    -- 解冻玩家
    Wait(500)
    FreezeEntityPosition(playerPed, false)

    -- 淡入效果
    DoScreenFadeIn(500)

    debug_print("玩家已成功传送到航空母舰")
end)

print("^2[yx_Island]^0 复活系统客户端模块已加载")
